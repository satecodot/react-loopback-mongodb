# React-Loopback-MongoDB
Menghubungkan antara react dengan loopback+MongoDB
